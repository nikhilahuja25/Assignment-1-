﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NAhujaAssignment01
{
   
    public partial class Form1 : Form
    {
        string[,] nikks = new string[5, 3];
        string[] w = new string[10];
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void button15_Click(object sender, EventArgs e)
        {
            
            if (textBox1.Text == "")
            {
                MessageBox.Show("PLEASE ENTER YOUR NAME");
            }
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                nikks[0, 0] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                nikks[0, 1] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                nikks[0, 2] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                nikks[1, 0] = textBox1.Text;
            }
            
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                nikks[1, 1] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                nikks[1, 2] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                nikks[2, 0] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                nikks[2, 1] = textBox1.Text;
               
            }
            
                if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                nikks[2, 2] = textBox1.Text;
               
            }
            
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                nikks[3, 0] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                nikks[3, 1] = textBox1.Text;
            }
            
            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                nikks[3, 2] = textBox1.Text;
            }
            
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                nikks[4, 0] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                nikks[4, 1] = textBox1.Text;
            }
           
            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                nikks[4, 2] = textBox1.Text;
            }
            

        }

        private void button22_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    nikks[i, j] = "NIKHIL";
                }
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    richTextBox1.Text += nikks[i, j] + "\n";
                }
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                nikks[0, 0] = "";
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                nikks[0, 1] = "";
            }

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                nikks[0, 2] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                nikks[1, 0] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                nikks[1, 1] = "";
            }

            if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                nikks[1, 2] = "";
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                nikks[2, 0] = "";
            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                nikks[2, 1] = "";

            }

            if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                nikks[2, 2] = "";

            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                nikks[3, 0] = "";
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                nikks[3, 1] = "";
            }

            if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                nikks[3, 2] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                nikks[4, 0] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                nikks[4, 1] = "";
            }

            if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                nikks[4, 2] = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < 5; i++)
                {
                    for (int j = 0; j < 3; j++)
                        if (nikks[i, j] == "")
                        {
                            /*---EXCEPTION---*/
                        }
                        else
                        { 
                         if (w[0] == "")
                            {
                                w[0] = textBox1.Text;
                            }
                            else if (w[1] == "")
                            {
                                w[1] = textBox1.Text;
                            }
                            else if (w[2] == "")
                            {
                                w[2] = textBox1.Text;
                            }
                            else if (w[3] == "")
                            {
                                w[3] = textBox1.Text;
                            }
                            else if (w[4] == "")
                            {
                                w[4] = textBox1.Text;
                            }
                            else if (w[5] == "")
                            {
                                w[5] = textBox1.Text;
                            }
                            else if (w[6] == "")
                            {
                                w[6] = textBox1.Text;
                            }
                            else if (w[7] == "")
                            {
                                w[7] = textBox1.Text;
                            }
                            else if (w[8] == "")
                            {
                                w[8] = textBox1.Text;
                            }
                            else if (w[9] == "")
                            {
                                w[9] = textBox1.Text;
                            }
                        }
                   

                }
            }
            catch(Exception)
            { }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                richTextBox4.Text += w[i] + "\n";
            }
        }
    }
}
